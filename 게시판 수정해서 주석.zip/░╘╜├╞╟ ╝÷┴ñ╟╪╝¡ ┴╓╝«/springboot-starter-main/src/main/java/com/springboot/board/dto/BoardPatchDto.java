package com.springboot.board.dto;

import com.springboot.board.entity.Board;
import lombok.Getter;

import javax.validation.constraints.NotBlank;
@Getter
public class BoardPatchDto {
    private long boardId;
    private long memberId;
    @NotBlank
    private String title;
    @NotBlank
    private String boardContents;
    Board.BoardStatus boardStatus;
    Board.PrivacyStatus privacyStatus;

}
