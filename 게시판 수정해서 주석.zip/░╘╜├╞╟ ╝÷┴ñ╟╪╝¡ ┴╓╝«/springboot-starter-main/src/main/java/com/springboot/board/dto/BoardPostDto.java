package com.springboot.board.dto;

import lombok.Getter;

import javax.validation.constraints.NotBlank;

@Getter
public class BoardPostDto {
    private long memberId;
    @NotBlank
    private String title;
    @NotBlank
    private String boardContents;


}
