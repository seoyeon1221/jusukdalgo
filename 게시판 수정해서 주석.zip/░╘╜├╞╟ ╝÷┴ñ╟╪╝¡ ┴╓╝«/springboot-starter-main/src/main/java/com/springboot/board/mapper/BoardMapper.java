package com.springboot.board.mapper;

import com.springboot.board.dto.BoardPatchDto;
import com.springboot.board.dto.BoardPostDto;
import com.springboot.board.dto.BoardResponseDto;
import com.springboot.board.entity.Board;
import com.springboot.comment.dto.CommentResponseDto;
import com.springboot.comment.entity.Comment;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;
import java.util.stream.Collectors;

@Mapper(componentModel = "spring")
public interface BoardMapper{
    @Mapping(source = "memberId" ,target = "member.memberId")
    Board boardPostDtoToBoard(BoardPostDto boardPostDto);

    @Mapping(source = "boardId", target = "boardId")
    @Mapping(source = "memberId",target = "member.memberId")
    @Mapping(source = "title", target = "title")
    @Mapping(source = "boardContents", target = "boardContents")
    @Mapping(source = "boardStatus", target = "boardStatus")
    @Mapping(source = "privacyStatus", target = "privacyStatus")
    Board boardPatchDtoToBoard(BoardPatchDto boardPatchDto);

//    @Mapping(source = "member.email", target = "username")
    default BoardResponseDto boardToBoardResponseDto(Board board){
        return new BoardResponseDto(
                board.getBoardId(),
                board.getTitle(),
                board.getBoardContents(),
                board.getPrivacyStatus(),
                board.getBoardStatus(),
                board.getCreatedAt(),
                board.getModifiedAt(),
                board.getMember().getEmail(),
                commentsToCommentResponseDtos(board.getComments())
        );
    }

//    @Mapping(source = "boardId", target = "boardId")
//    @Mapping(source = "title", target = "title")
//    @Mapping(source = "boardContents", target = "boardContents")
//    @Mapping(source = "privacyStatus", target = "privacyStatus")
//    @Mapping(source = "boardStatus", target = "boardStatus")
//    @Mapping(source = "createdAt", target = "modifiedAt")
//    @Mapping(source = "member.name", target = "username")
    default List<BoardResponseDto> BoardsToBoardResponseDtos(List<Board> boardList) {
        return boardList.stream()
                .map(board -> {
                    return new BoardResponseDto(
                            board.getBoardId(),
                            board.getTitle(),
                            board.getBoardContents(),
                            board.getPrivacyStatus(),
                            board.getBoardStatus(),
                            board.getCreatedAt(),
                            board.getModifiedAt(),
                            board.getMember().getEmail(),
                            commentsToCommentResponseDtos(board.getComments())
                    );
                }).collect(Collectors.toList());
    }

//    @Mapping(source = "comment" ,target = "comment")
    default List<CommentResponseDto> commentsToCommentResponseDtos(List<Comment> comments) {
        return comments.stream()
                .map(comment -> {
                    CommentResponseDto commentResponseDto = new CommentResponseDto();
                    commentResponseDto.setComment(comment.getComment());
                    commentResponseDto.setCreatedAt(comment.getCreatedAt());
                    return commentResponseDto;
                }).collect(Collectors.toList());
    }
}
