package com.springboot.board.service;

import com.springboot.board.entity.Board;
import com.springboot.board.repository.BoardRepository;
import com.springboot.comment.entity.Comment;
import com.springboot.comment.service.CommentService;
import com.springboot.exception.BusinessLogicException;
import com.springboot.exception.ExceptionCode;
import com.springboot.member.entity.Member;
import com.springboot.member.service.MemberService;
import com.springboot.response.PageDirection;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class BoardService {
    private final MemberService memberService;
    private final BoardRepository boardRepository;
//    private final CommentService commentService;


    public BoardService(MemberService memberService, BoardRepository boardRepository) {
        this.memberService = memberService;
        this.boardRepository = boardRepository;
    }

    public Board createContents(Board board) {
        Member member = memberService.findVerifiedMember(board.getMember().getMemberId());
        board.setMember(member);
        memberService.verifyMemberStatus(member);
        return boardRepository.save(board);
    }

    public Board updateBoard(Board board) {
        Board findBoard = findVerifyExistBoard(board.getBoardId());
        Member member = memberService.findVerifiedMember(board.getMember().getMemberId());
        board.setMember(member);
        memberService.verifyMemberStatus(member);

        verifyBoardStatus(findBoard.getBoardId());
        Optional.ofNullable(board.getTitle())
                .ifPresent(title -> findBoard.setTitle(title));
        Optional.ofNullable(board.getBoardContents())
                .ifPresent(boardContents -> findBoard.setBoardContents(boardContents));
        Optional.ofNullable(board.getBoardStatus())
                .ifPresent(boardStatus -> findBoard.setBoardStatus(boardStatus));
        Optional.ofNullable(board.getPrivacyStatus())
                .ifPresent(privacyStatus -> findBoard.setPrivacyStatus(privacyStatus));

        if (findBoard.getPrivacyStatus().equals(Board.PrivacyStatus.BOARD_PUBLIC)) {
            findBoard.getComments().forEach(comment ->
                    comment.setCommentPrivacyStatus(Comment.CommentPrivacyStatus.COMMENT_PUBLIC));
        } else {
            findBoard.getComments().forEach(comment ->
                    comment.setCommentPrivacyStatus(Comment.CommentPrivacyStatus.COMMENT_SECRET));
        }

        findBoard.setModifiedAt(LocalDateTime.now());


        return boardRepository.save(findBoard);
    }

    public Board getBoard(long boardId) {
        verifyBoardStatus(boardId);
        return findVerifyExistBoard(boardId);
    }

    public Page<Board> getBoards(int page, int size, String direction) {

        PageDirection enumDirection =PageDirection.valueOf(direction);

            Page<Board> boardList;
            switch (enumDirection) {
                case PAGE_CREATEDATDESC :
                    boardList = boardRepository.findByBoardStatusNotAndBoardStatusNot(
                            Board.BoardStatus.QUESTION_DEACTIVED, Board.BoardStatus.QUESTION_DELETED,
                            PageRequest.of(page, size, Sort.by("createdAt").descending()));
                    break;

                case PAGE_CREATEDATASC :
                    boardList = boardRepository.findByBoardStatusNotAndBoardStatusNot(
                            Board.BoardStatus.QUESTION_DEACTIVED, Board.BoardStatus.QUESTION_DELETED,
                            PageRequest.of(page, size, Sort.by("createdAt").ascending()));
                    break;

                case PAGE_LIKESDESC :
                    boardList = boardRepository.findByBoardStatusNotAndBoardStatusNot(
                            Board.BoardStatus.QUESTION_DEACTIVED, Board.BoardStatus.QUESTION_DELETED,
                            PageRequest.of(page, size, Sort.by("likes").descending()));
                    break;

                case PAGE_LIKESASC :
                    boardList = boardRepository.findByBoardStatusNotAndBoardStatusNot(
                            Board.BoardStatus.QUESTION_DEACTIVED, Board.BoardStatus.QUESTION_DELETED,
                            PageRequest.of(page, size, Sort.by("likes").ascending()));
                    break;

                case PAGE_VIEWSDESC :
                    boardList = boardRepository.findByBoardStatusNotAndBoardStatusNot(
                            Board.BoardStatus.QUESTION_DEACTIVED, Board.BoardStatus.QUESTION_DELETED,
                            PageRequest.of(page, size, Sort.by("views").descending()));
                    break;

                case PAGE_VIEWSASC:
                    boardList = boardRepository.findByBoardStatusNotAndBoardStatusNot(
                            Board.BoardStatus.QUESTION_DEACTIVED, Board.BoardStatus.QUESTION_DELETED,
                            PageRequest.of(page, size, Sort.by("views").ascending()));
                    break;

                default:
                    throw new IllegalArgumentException("Invalid direction parameter: " + direction);
            }
            return boardList;
    }

    public void deleteBoard(long boardId) {
        Board findBoard = findVerifyExistBoard(boardId);
        verifyBoardStatus(findBoard.getBoardId());
        findBoard.setBoardStatus(Board.BoardStatus.QUESTION_DELETED);
        findBoard.setModifiedAt(LocalDateTime.now());
        boardRepository.save(findBoard);
    }

    public Board findVerifyExistBoard(long boardId) {
        Optional<Board> board = boardRepository.findById(boardId);
        return board.orElseThrow(() -> new BusinessLogicException(ExceptionCode.BOARD_NOT_FOUND));
    }

    public void verifyBoardStatus(long boardId) {
        Board findBoard = findVerifyExistBoard(boardId);
        if (findBoard.getBoardStatus().equals(Board.BoardStatus.QUESTION_DELETED)
                || findBoard.getBoardStatus().equals(Board.BoardStatus.QUESTION_DEACTIVED)) {
            throw new BusinessLogicException(ExceptionCode.QUESTION_NOT_EXIST);
        }
    }

    public Board memberBoardStatus(Board board) {
        if (board.getMember().getMemberStatus().equals(Member.MemberStatus.MEMBER_QUIT) ||
                board.getMember().getMemberStatus().equals(Member.MemberStatus.MEMBER_SLEEP)) {
            board.setBoardStatus(Board.BoardStatus.QUESTION_DEACTIVED);
        }
        return boardRepository.save(board);
    }

}
