package com.springboot.comment.dto;

import com.springboot.comment.entity.Comment;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@NoArgsConstructor
@Setter
@Getter
public class CommentResponseDto {
    private String comment;
    private LocalDateTime createdAt;
}
