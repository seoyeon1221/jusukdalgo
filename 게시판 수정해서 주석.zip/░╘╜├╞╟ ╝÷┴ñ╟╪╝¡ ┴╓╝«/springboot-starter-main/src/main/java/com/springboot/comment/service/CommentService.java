package com.springboot.comment.service;

import com.springboot.board.entity.Board;
import com.springboot.board.service.BoardService;
import com.springboot.comment.entity.Comment;
import com.springboot.comment.repository.CommentRepository;
import com.springboot.exception.BusinessLogicException;
import com.springboot.exception.ExceptionCode;
import com.springboot.member.entity.Member;
import com.springboot.member.repository.MemberRepository;
import com.springboot.member.service.MemberService;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class CommentService {
    private final CommentRepository commentRepository;
    private final BoardService boardService;
    private final MemberService memberService;

    public CommentService(CommentRepository commentRepository, BoardService boardService, MemberService memberService) {
        this.commentRepository = commentRepository;
        this.boardService = boardService;
        this.memberService = memberService;
    }

    public Comment createComment(Comment comment) {
        Board board = boardService.findVerifyExistBoard(comment.getBoard().getBoardId());
        boardService.verifyBoardStatus(board.getBoardId());
        Member member = memberService.findVerifiedMember(comment.getMember().getMemberId());
        memberService.verifyMemberStatus(member);
        comment.setMember(member);
        comment.setBoard(board);
        Comment verifyComment = verifyPrivacyStatus(comment);
//        답변이 생성될 때 board의 상태가 답변완료로 바껴야함

        board.setBoardStatus(Board.BoardStatus.QUESTION_ANSWERED);

        return commentRepository.save(verifyComment);
    }

//    매개변수로 받은 comment entity를 디비에서 board 공개여부를 확인하고 해당맞춰서 반환해줌
    public Comment verifyPrivacyStatus(Comment comment) {
        Board board = boardService.findVerifyExistBoard(comment.getBoard().getBoardId());
        if (board.getPrivacyStatus().getStepNumber() == 1){
            comment.setCommentPrivacyStatus(Comment.CommentPrivacyStatus.COMMENT_PUBLIC);
        } else{ comment.setCommentPrivacyStatus(Comment.CommentPrivacyStatus.COMMENT_SECRET);
            comment.setBoard(board);
    } return comment;
    }

    public Comment verifyExistComment(long commentId) {
        Optional<Comment> optionalComment = commentRepository.findById(commentId);
        return optionalComment.orElseThrow(() -> new BusinessLogicException(ExceptionCode.COMMENT_NOT_EXIST));
    }
}
