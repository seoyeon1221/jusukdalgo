package com.springboot.member.entity;

import com.springboot.board.entity.Board;
import com.springboot.comment.entity.Comment;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Getter
@Setter
@NoArgsConstructor
public class Member {
//    Entity 게터 세터 기본생성자 필수
//    생성전략 및 Id임을 알려줘야함
//    멤버의 활동 상태를 내부 enum 클래스로 내부클래스안에 필드값에는 Getter를 붙여서 가져올 수 있게 해야함.
//    그리고 entity에 Enumerate - 타입도 지정해줘야함 현재는 String 생성시 멤버는 무조건 활동중으로

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long memberId;
    @Column(nullable = false, length = 30)
    private String name;
    @Column(nullable = false, unique = true, updatable = false)
    private String email;
    @Column(nullable = false, length = 13)
    private String phone;
    @Column(nullable = false, updatable = false)
    LocalDateTime createdAt = LocalDateTime.now();
    @Column(nullable = false, name = "LAST_MODIFIED_AT")
    LocalDateTime modifiedAt = LocalDateTime.now();
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 30)
    MemberStatus memberStatus = MemberStatus.MEMBER_ACTIVE;
    @OneToMany(mappedBy = "member")
    private List<Comment> comments = new ArrayList<>();
    public void setComment(Comment comment){
        comments.add(comment);
        if(comment.getMember() != this){
            comment.setMember(this);
        }
    }

    @OneToMany(mappedBy = "member",cascade = CascadeType.REFRESH)
    private List<Board> boards = new ArrayList<>();
    public void setBoard(Board board) {
        boards.add(board);
        if (board.getMember() != this) {
            board.setMember(this);
        }
    }


    public enum MemberStatus {
        MEMBER_ACTIVE("활동 회원"),
        MEMBER_SLEEP("휴면 회원"),
        MEMBER_QUIT("탈퇴 회원");

        @Getter
        private String status;

        MemberStatus(String status) {
            this.status = status;
        }
    }


}
