package spingboot.board.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import spingboot.board.dto.BoardPatchDto;
import spingboot.board.dto.BoardPostDto;
import spingboot.board.entity.Board;
import spingboot.board.mapper.BoardMapper;
import spingboot.board.service.BoardService;
import spingboot.response.MultiResponseDto;
import spingboot.response.SingleResponseDto;
import spingboot.utils.UriCreator;

import javax.validation.Valid;
import javax.validation.constraints.Positive;
import java.net.URI;

@RestController
@RequestMapping("/ver1/boards")
@Validated
@Slf4j
public class BoardController {
    private static final String BOARD_DEFAULT_URL = "/ver1/boards";
    private final BoardService boardService;
    private final BoardMapper mapper;

    public BoardController(BoardService boardService, BoardMapper mapper) {
        this.boardService = boardService;
        this.mapper = mapper;
    }

    @PostMapping
    public ResponseEntity postBoard(@Valid @RequestBody BoardPostDto boardPostDto) {
        Board postBoard = boardService.createContents(mapper.boardPostDtoToBoard(boardPostDto));
        URI location = UriCreator.createUri(BOARD_DEFAULT_URL, postBoard.getBoardId());
        return ResponseEntity.created(location).build();
    }


    @GetMapping("/{board-id}")
    public ResponseEntity getBoard(@PathVariable("board-id") @Positive long boardId) {
        Board getBoard = boardService.findVerifyExistBoard(boardId);
        boardService.verifyBoardStatus(getBoard.getBoardId());
        return new ResponseEntity<>(new SingleResponseDto<>(mapper.boardToBoardResponseDto(getBoard)), HttpStatus.OK);
    }

    @GetMapping()
    public ResponseEntity getBoards(@Positive @RequestParam int page, @Positive @RequestParam int size, @RequestParam String direction) {
        Page<Board> boardPage = boardService.getBoards(page-1, size, direction);
//        List<Board> boardList = boardPage.getContent().stream()
//                .filter(board -> board.getBoardStatus() != Board.BoardStatus.QUESTION_DELETED)
//                .collect(Collectors.toList());

        return new ResponseEntity<>(
                new MultiResponseDto<>(mapper.boardsToBoardResponseDtos(boardPage.getContent()), boardPage), HttpStatus.OK);
//        return new ResponseEntity<>(
//                new MultiResponseDto<>(mapper.BoardsToBoardResponseDtos(boardList), boardPage), HttpStatus.OK);
    }

    @PatchMapping("/{board-id}")
    public ResponseEntity patchBoard(@PathVariable("board-id") @Positive long boardId, @RequestBody BoardPatchDto boardPatchDto) {
        boardService.findVerifyExistBoard(boardId);
        Board board = mapper.boardPatchDtoToBoard(boardPatchDto);
        Board updateBoard = boardService.updateBoard(board);
        return new ResponseEntity<>(mapper.boardToBoardResponseDto(updateBoard), HttpStatus.OK);
    }

    @DeleteMapping("/{board-id}")
    public ResponseEntity deleteBoard(@PathVariable("board-id") @Positive long boardId) {
        boardService.deleteBoard(boardId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
