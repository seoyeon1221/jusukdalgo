package spingboot.board.dto;

import lombok.Getter;
import spingboot.board.entity.Board;

import javax.validation.constraints.NotBlank;
@Getter
public class BoardPatchDto {
    // 수정할 때 필요한 정보들
    private long boardId;
    private long memberId;
    @NotBlank
    private String title;
    @NotBlank
    // 포스트 공개 비공개 설정과 현상태(답글이 달렸는지 --> 답글이 달렸을때는 QUESTION_ANSWERED 등등..)
    private String boardContents;
    Board.BoardStatus boardStatus;
    Board.PrivacyStatus privacyStatus;

}
