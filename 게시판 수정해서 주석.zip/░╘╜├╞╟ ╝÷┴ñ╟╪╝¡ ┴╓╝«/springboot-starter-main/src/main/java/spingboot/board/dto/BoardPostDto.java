package spingboot.board.dto;

import lombok.Getter;

import javax.validation.constraints.NotBlank;

// dto는 항상 클라이언트에 요청할 때 나가는 최소한(필요한)의 정보만 담겨있음
@Getter
public class BoardPostDto {
    private long memberId;
    @NotBlank
    private String title;
    @NotBlank
    private String boardContents;


}
