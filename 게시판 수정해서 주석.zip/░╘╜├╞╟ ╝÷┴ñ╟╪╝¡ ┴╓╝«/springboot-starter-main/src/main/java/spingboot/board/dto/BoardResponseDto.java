package spingboot.board.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import spingboot.board.entity.Board;
import spingboot.comment.dto.CommentResponseDto;

import java.time.LocalDateTime;
import java.util.List;

@Getter
@AllArgsConstructor
// 클라이언트에 실질적으로 나가는 정보들(게시물 올렸을 때 나가는 정보들)
public class BoardResponseDto {
    private long boardId;
    private String title;
    private String boardContents;
    private Board.PrivacyStatus privacyStatus;
    private Board.BoardStatus boardStatus;
    private LocalDateTime createdAt;
    private LocalDateTime modifiedAt;
    private String username;
    private List<CommentResponseDto> comments;
}
