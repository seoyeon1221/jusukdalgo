package spingboot.board.entity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import spingboot.comment.entity.Comment;
import spingboot.member.entity.Member;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@Entity
@NoArgsConstructor
public class Board {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long boardId;

    @Column(nullable = false)
    private String title;

    @Column(nullable = false)
    private String boardContents;

    @Enumerated(EnumType.STRING)
    BoardStatus boardStatus = BoardStatus.QUESTION_REGISTERED;

    @Enumerated(EnumType.STRING)
    PrivacyStatus privacyStatus = PrivacyStatus.BOARD_PUBLIC;

    @Column(nullable = false, updatable = false)
    LocalDateTime createdAt = LocalDateTime.now();

    @Column(nullable = false, name = "LAST_MODIFIED_AT")
    LocalDateTime modifiedAt = LocalDateTime.now();

    // 하나의 게시물은 하나의 멤버에 귀속되지만 한명의 회원은 여러개를 쓸 수 있지
    @ManyToOne()
    @JoinColumn(name = "MEMBER_ID")
    private Member member;

    // 본래 하나의 코멘트애는 하나의 댓글만 가능하므로 리스트까지는 필요 없는 것 같은데 오빠는 이렇게 걍 한듯
    @OneToMany(mappedBy = "board",cascade = CascadeType.REFRESH)
    private List<Comment> comments = new ArrayList<>();
    public void setComment(Comment comment){
        comments.add(comment);
        if(comment.getBoard() != this ){
            comment.setBoard(this);
        }
    }
    // 보드랑 양방향 관계설정위한 메서드
    // 멤버엔티티의 63번째 줄 누르면 일로옴
    public void setMember(Member member) {
        this.member = member;
        if (!member.getBoards().contains(this)) {
            member.setBoard(this);
        }

    }

    // 게시글의 현 상태를 나타내는 이넘
    @Getter
    public enum BoardStatus {
        QUESTION_REGISTERED("질문 등록 상태", 1),
        QUESTION_ANSWERED("답변 완료 상태", 2),
        QUESTION_DELETED("질문 삭제 상태", 3),
        QUESTION_DEACTIVED("질문 비활성화 상태", 4);
        private String status;
        private int stepNumber;

        BoardStatus(String status, int stepNumber) {
            this.status = status;
            this.stepNumber = stepNumber;
        }
    }

    // 게시글의 공개 상태 나타내는 이넘
    public enum PrivacyStatus {
        BOARD_PUBLIC("전체 공개", 1),
        BOARD_SECRET("비공개", 2);
        @Getter
        private String status;

        @Getter
        private int stepNumber;

        PrivacyStatus(String status, int stepNumber) {
            this.status = status;
            this.stepNumber = stepNumber;
        }
    }


}
