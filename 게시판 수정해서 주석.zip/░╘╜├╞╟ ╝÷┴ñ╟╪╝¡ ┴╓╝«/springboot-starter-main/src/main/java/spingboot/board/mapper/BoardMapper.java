package spingboot.board.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import spingboot.board.dto.BoardPatchDto;
import spingboot.board.dto.BoardPostDto;
import spingboot.board.dto.BoardResponseDto;
import spingboot.board.entity.Board;
import spingboot.comment.dto.CommentResponseDto;
import spingboot.comment.entity.Comment;

import java.util.List;
import java.util.stream.Collectors;

// componentModel = "spring"는 매퍼 인터페이스를
// Spring 컨텍스트에서 사용할 수 있는 빈으로 등록하도록 지정
// 이로 인해 Spring의 의존성 주입(Dependency Injection)을
// 통해 매퍼 빈을 주입받아 사용가능
@Mapper(componentModel = "spring")
public interface BoardMapper {
    // 매핑규칙을 정의하는 에너테이션
    // source = "memberId" BoardPostDto객체인
    // boardPostDto의 memberId 필드를 의미 즉, 객체안의 memberId를 사용하겠다는뜻
    // target = "member.memberId"는 Board 객체의
    // 멤버필드 내부의 memberId의미.
    // 왜 소스와 타겟의 출처 객체가 다르냐?
    // Dto 객체의 데이터를 엔티티 객체로 변환하는 과정에서 서로 다른 객체의 필드를 매핑해야 함 그래서 이 변환 과정에서 source와 target이 서로 다른 객체를 참조하게 된다한다 ㅇㅅㅇ
    // 정리하자면 맵핑에너테이션을 통해 디티오의 멤버 아이디를 엔티티의 멤버아디로 변환하는거임
    @Mapping(source = "memberId", target = "member.memberId")
    Board boardPostDtoToBoard(BoardPostDto boardPostDto);

    // 패치할 때 디티오 객체의 각 필드를 엔티티 객체에 대응되게 하나씩 맵핑한거
    @Mapping(source = "boardId", target = "boardId")
    @Mapping(source = "memberId", target = "member.memberId")
    @Mapping(source = "title", target = "title")
    @Mapping(source = "boardContents", target = "boardContents")
    @Mapping(source = "boardStatus", target = "boardStatus")
    @Mapping(source = "privacyStatus", target = "privacyStatus")
    Board boardPatchDtoToBoard(BoardPatchDto boardPatchDto);


    // 그렇다면 얘는 왜 따로 맵핑시키지 않고 저렇게 연결시킨거지..? 이거는 꼭 파악하기
    // 파라미터로 엔티티 객체를 받아 직접적으로 디티오로 변환하는 메서드
    default BoardResponseDto boardToBoardResponseDto(Board board) {
        // 새로운 BoardResponseDto 디티오객체를 반환함
        return new BoardResponseDto(
                // 보드의 보드아이디 가져옴
                board.getBoardId(),
                // 보드의 타이틀 가져옴
                board.getTitle(),
                // 보드의 컨텐츠 가져옴
                board.getBoardContents(),
                // 보드의 현상태 가져옴
                board.getPrivacyStatus(),
                // 보드의 게시상태 가져옴
                board.getBoardStatus(),
                // 보드의 생성시간 가져옴
                board.getCreatedAt(),
                // 보드의 데이터타임가져옴? 모더라
                board.getModifiedAt(),
                // 보드에 있는 멤버필드의 이메일 가져옴
                board.getMember().getEmail(),
                // 보드엔티티의 코멘트들을 코멘트디티오로 변환 --> 엔티티를 디티오로 변환하는 메서드이기 때문에 안에 있는 코멘트엔티티 필드도 디티오로 직접적으로 변환하는것!
                commentsToCommentResponseDtos(board.getComments())
        );
    }

// 영진오빠가 짠 메서드 게시판들 조회하기 위한것 밑의 메서드는 기능은 같지만 위에 만든 메서드를 활용해서 조회한 메서드 즉, 코드의 중복과 확장성 높인거임
    // 리스트 리스판스의 디티오인데 엔티티를 리스판스디티오들로 변환하는 메서드 근데 이걸 왜 두개나 만들었을지 생각하기
    // 여러 개의 보드엔티티를 한번에 여러 개의 디티오로 변환하는 메서드 즉, 요구조건에 있는 여러게시판을 조회하기 위한 메서드임
//    // 람다함수를 사용하여 변환
//    default List<BoardResponseDto> BoardsToBoardResponseDtos(List<Board> boardList) {
//         // 보드리스트를 스트림으로 변환하여 각 보드 객체를 처리하는 것
//        return boardList.stream()
//                // 각 보드객체를 보드디티오로 변환
//                .map(board -> {
//                    return new BoardResponseDto(
//                            // // 보드객체의 아이디를 보드디티오에 설정
//                            board.getBoardId(),
//                            // 보드객체의 타이틀 보드디티오로설정
//                            board.getTitle(),
//                            // 보드의 컨텐츠 보드디티오로설정
//                            board.getBoardContents(),
//                            // 보드의 공개상태 보드디티오로설정
//                            board.getPrivacyStatus(),
//                            // 보드의 현상태 보드디티오로설정
//                            board.getBoardStatus(),
//                            // 보드의 생성시간 보드디티오로설정
//                            board.getCreatedAt(),
//                            // 보드의 수정일자 보드디티오로설정
//                            board.getModifiedAt(),
//                            // 보드의 멤바필드의 이메일을 보드디티오로설정
//                            board.getMember().getEmail(),
//
//
//                            // 보드엔티티의 댓글 리스트를 코멘트디티오로 변환하여 보드디티오에 설정
//                             commentsToCommentResponseDtos(board.getComments())
//                    );
//                    // 변환된 디티오객체들을 리스트로 수집하는것
//                }).collect(Collectors.toList());
//    }

    // 이게 위랑 같은메서드
    // 여러 개의 보드객체를 보드디티오리스트로 변환하는 메서드임
    default List<BoardResponseDto>
    // 보드디티오 리스트를 스트림으로 변환하여 각 보드 객체를 처리
    boardsToBoardResponseDtos(List<Board> boardList) {
        return boardList.stream()
                // 각 보드객체들를 위에 만든 boardToBoardResponseDto 메서드를 이용하여 디티오들로 변환
                // this::boardToBoardResponseDto에서 ::는 메서드 참조(method reference)를 나타내는 연산자임.
                // 이는 자바 8에서 도입된 람다 표현식의 간결한 표현 방식 중 하나ㅇㅇ
                // 즉 .map(board -> this.boardToBoardResponseDto(board)) 람다표현식과 같음 각 보드 객체를 this.boardToBoardResponseDto(board) 메서드에 전달하여 변환하는 역할인데 더 간결하게 표현하는 람다식임
                .map(this::boardToBoardResponseDto)
                .collect(Collectors.toList());
    }

    // boardToBoardResponseDto에 사용되는 보드의 코멘트 엔티티들을 코멘트 디티오들로 변환하는 매퍼메서드
    default List<CommentResponseDto>
    commentsToCommentResponseDtos(List<Comment> comments) {
        // 코멘트들의 리스트를 스트림으로 변환하여 각 코멘트객체를 처리하는거
        return comments.stream()
                // 각 코멘트 객체를 코멘트 디티오로 변환
                .map(comment -> {
                    // 새로운 commentResponseDto객체 생성
                    CommentResponseDto commentResponseDto = new CommentResponseDto();
                    // 코멘트 객체의 내용을 CommentResponseDto에 설정
                    commentResponseDto.setComment(comment.getComment());
                    // 코멘트 생성일자를 commentResponseDto에 설정
                    commentResponseDto.setCreatedAt(comment.getCreatedAt());
                    // commentResponseDto에 설정한거를 반환하고
                    return commentResponseDto;
                    // 변환된 CommentResponseDto 객체들을 리스트들로 수정
                }).collect(Collectors.toList());
    }
}
