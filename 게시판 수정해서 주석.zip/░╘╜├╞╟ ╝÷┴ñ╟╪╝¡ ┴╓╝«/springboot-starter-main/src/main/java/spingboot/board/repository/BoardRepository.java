package spingboot.board.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import spingboot.board.entity.Board;

public interface BoardRepository extends JpaRepository<Board, Long> {
    //    2개 상태를 제외하고 페이지네이션으로 받아오고 싶은 경우 구현한 뒤 서비스 계층에서 수정

    Page<Board> findByBoardStatusNotAndBoardStatusNot(Board.BoardStatus boardStatus1, Board.BoardStatus boardStatus2, Pageable pageable);


}


