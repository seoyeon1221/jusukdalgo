package spingboot.board.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import spingboot.board.entity.Board;
import spingboot.board.repository.BoardRepository;
import spingboot.comment.entity.Comment;
import spingboot.exception.BusinessLogicException;
import spingboot.exception.ExceptionCode;
import spingboot.member.entity.Member;
import spingboot.member.service.MemberService;
import spingboot.response.PageDirection;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class BoardService {
    // 여기에 왜 코멘트 서비스를 사용하지 않은걸까?
    //
    private final MemberService memberService;
    private final BoardRepository boardRepository;
//    private final CommentService commentService;


    public BoardService(MemberService memberService, BoardRepository boardRepository) {
        this.memberService = memberService;
        this.boardRepository = boardRepository;
    }

    public Board createContents(Board board) {
        Member member = memberService.findVerifiedMember(board.getMember().getMemberId());
        board.setMember(member);
        memberService.verifyMemberStatus(member);
        return boardRepository.save(board);
    }

    //  게시판 수정하는 코드
    public Board updateBoard(Board board) {
    // 보드 아이디가 있다면 레파지토리에 있는걸 가져오고 없다면 예외던지는 메서드findVerifyExistBoard를 통해 있는 게시글을 findBoard에 담음
        Board findBoard = findVerifyExistBoard(board.getBoardId());
        // 멤버서비스의 멤버가 있다면 레파지토리에 있는걸 가져오고 없다면 예외던지는 findVerifiedMember 통해 있는 멤버아이디를 member객체에 넣음
        Member member = memberService.findVerifiedMember(board.getMember().getMemberId());
        // 이후 보드엔티티의 멤버를 가져와서 수정
        board.setMember(member);
        // 멤버서비스의 verifyMemberStatus를 통해 멤버가 있다면 멤버상태를 나타나게끔
        memberService.verifyMemberStatus(member);

        // 보드
        verifyBoardStatus(findBoard.getBoardId());
        Optional.ofNullable(board.getTitle())
                .ifPresent(title -> findBoard.setTitle(title));
        Optional.ofNullable(board.getBoardContents())
                .ifPresent(boardContents -> findBoard.setBoardContents(boardContents));
        Optional.ofNullable(board.getBoardStatus())
                .ifPresent(boardStatus -> findBoard.setBoardStatus(boardStatus));
        Optional.ofNullable(board.getPrivacyStatus())
                .ifPresent(privacyStatus -> findBoard.setPrivacyStatus(privacyStatus));

        if (findBoard.getPrivacyStatus().equals(Board.PrivacyStatus.BOARD_PUBLIC)) {
            findBoard.getComments().forEach(comment ->
                    comment.setCommentPrivacyStatus(Comment.CommentPrivacyStatus.COMMENT_PUBLIC));
        } else {
            findBoard.getComments().forEach(comment ->
                    comment.setCommentPrivacyStatus(Comment.CommentPrivacyStatus.COMMENT_SECRET));
        }

        findBoard.setModifiedAt(LocalDateTime.now());


        return boardRepository.save(findBoard);
    }

    public Board getBoard(long boardId) {
        verifyBoardStatus(boardId);
        return findVerifyExistBoard(boardId);
    }

    public Page<Board> getBoards(int page, int size, String direction) {

        PageDirection enumDirection = PageDirection.valueOf(direction);

            Page<Board> boardList;
            switch (enumDirection) {
                case PAGE_CREATEDATDESC :
                    boardList = boardRepository.findByBoardStatusNotAndBoardStatusNot(
                            Board.BoardStatus.QUESTION_DEACTIVED, Board.BoardStatus.QUESTION_DELETED,
                            PageRequest.of(page, size, Sort.by("createdAt").descending()));
                    break;

                case PAGE_CREATEDATASC :
                    boardList = boardRepository.findByBoardStatusNotAndBoardStatusNot(
                            Board.BoardStatus.QUESTION_DEACTIVED, Board.BoardStatus.QUESTION_DELETED,
                            PageRequest.of(page, size, Sort.by("createdAt").ascending()));
                    break;

                case PAGE_LIKESDESC :
                    boardList = boardRepository.findByBoardStatusNotAndBoardStatusNot(
                            Board.BoardStatus.QUESTION_DEACTIVED, Board.BoardStatus.QUESTION_DELETED,
                            PageRequest.of(page, size, Sort.by("likes").descending()));
                    break;

                case PAGE_LIKESASC :
                    boardList = boardRepository.findByBoardStatusNotAndBoardStatusNot(
                            Board.BoardStatus.QUESTION_DEACTIVED, Board.BoardStatus.QUESTION_DELETED,
                            PageRequest.of(page, size, Sort.by("likes").ascending()));
                    break;

                case PAGE_VIEWSDESC :
                    boardList = boardRepository.findByBoardStatusNotAndBoardStatusNot(
                            Board.BoardStatus.QUESTION_DEACTIVED, Board.BoardStatus.QUESTION_DELETED,
                            PageRequest.of(page, size, Sort.by("views").descending()));
                    break;

                case PAGE_VIEWSASC:
                    boardList = boardRepository.findByBoardStatusNotAndBoardStatusNot(
                            Board.BoardStatus.QUESTION_DEACTIVED, Board.BoardStatus.QUESTION_DELETED,
                            PageRequest.of(page, size, Sort.by("views").ascending()));
                    break;

                default:
                    throw new IllegalArgumentException("Invalid direction parameter: " + direction);
            }
            return boardList;
    }

    public void deleteBoard(long boardId) {
        Board findBoard = findVerifyExistBoard(boardId);
        verifyBoardStatus(findBoard.getBoardId());
        findBoard.setBoardStatus(Board.BoardStatus.QUESTION_DELETED);
        findBoard.setModifiedAt(LocalDateTime.now());
        boardRepository.save(findBoard);
    }

    // 보드 아이디가 있다면 레파지토리에 있는걸 가져오고 없다면 예외던지는 메서드
    public Board findVerifyExistBoard(long boardId) {
        Optional<Board> board = boardRepository.findById(boardId);
        return board.orElseThrow(() -> new BusinessLogicException(ExceptionCode.BOARD_NOT_FOUND));
    }


    public void verifyBoardStatus(long boardId) {
        Board findBoard = findVerifyExistBoard(boardId);
        // 찾은 보드에서 보드상태가 QUESTION_DELETED랑 같거나 QUESTION_DEACTIVED상태랑 같다면
        if (findBoard.getBoardStatus().equals(Board.BoardStatus.QUESTION_DELETED)
                || findBoard.getBoardStatus().equals(Board.BoardStatus.QUESTION_DEACTIVED)) {
            // 즉 둘중에 하나의 조건이라도 만족한다면 해당 보드를 찾을 수 없다는 예외 메세지를 보여주는 것
            throw new BusinessLogicException(ExceptionCode.QUESTION_NOT_EXIST);
        }
    }

    public Board memberBoardStatus(Board board) {
        // 만략 보드에서 가져온 멤버필드의 멤버상태가 MEMBER_QUIT나 MEMBER_SLEEP 둘중 하나라면
        if (board.getMember().getMemberStatus().equals(Member.MemberStatus.MEMBER_QUIT) ||
                board.getMember().getMemberStatus().equals(Member.MemberStatus.MEMBER_SLEEP)) {
            // 보드의 보드상태 QUESTION_DEACTIVED를 실행시킴
            board.setBoardStatus(Board.BoardStatus.QUESTION_DEACTIVED);
        } // 그리고 위의 과정을 보드의 레파지토리에 저장하고 저장한걸 반환함
        return boardRepository.save(board);
    }

}
