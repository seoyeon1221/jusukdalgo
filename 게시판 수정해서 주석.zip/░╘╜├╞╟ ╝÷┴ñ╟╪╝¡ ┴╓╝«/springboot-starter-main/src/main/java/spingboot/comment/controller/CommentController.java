package spingboot.comment.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import spingboot.comment.dto.CommentPostDto;
import spingboot.comment.entity.Comment;
import spingboot.comment.mapper.CommentMapper;
import spingboot.comment.service.CommentService;
import spingboot.utils.UriCreator;

import javax.validation.Valid;
import java.net.URI;

@RestController
@Validated
@RequestMapping("/ver1/boards/comments")
@Slf4j
public class CommentController {
    public static final String COMMENT_DEFAULT_URL = "/ver1/boards/comments";
    private CommentService commentService;
    private CommentMapper mapper;

    public CommentController(CommentService commentService, CommentMapper mapper) {
        this.commentService = commentService;
        this.mapper = mapper;
    }

    @PostMapping
    public ResponseEntity postComment(@Valid @RequestBody CommentPostDto commentPostDto){
        Comment postComment = commentService.createComment(mapper.commentPostDtoToComment(commentPostDto));
        URI location = UriCreator.createUri(COMMENT_DEFAULT_URL,postComment.getCommentId());
        return ResponseEntity.created(location).build();
    }



}
