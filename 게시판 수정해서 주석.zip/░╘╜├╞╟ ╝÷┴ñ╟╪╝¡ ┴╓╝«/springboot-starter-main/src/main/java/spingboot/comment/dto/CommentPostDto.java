package spingboot.comment.dto;

import lombok.Getter;

import javax.validation.constraints.NotBlank;

@Getter
public class CommentPostDto {
    private long boardId;
    private long memberId;
    @NotBlank
    private String comment;

}
