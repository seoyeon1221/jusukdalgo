package spingboot.comment.entity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import spingboot.board.entity.Board;
import spingboot.member.entity.Member;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@NoArgsConstructor
public class Comment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long commentId;
    @Column(nullable = false)
    private String comment;
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private CommentPrivacyStatus commentPrivacyStatus;
    @Column(nullable = false)
    LocalDateTime createdAt = LocalDateTime.now();
    @Column(nullable = false, name = "LAST_MODIFIED_AT")
    LocalDateTime modifiedAt = LocalDateTime.now();
    @ManyToOne
    @JoinColumn(name = "MEMBER_ID")
    private Member member;
    public void setMember(Member member) {
        this.member = member;
        if (!member.getComments().contains(this)) {
            member.setComment(this);
        }
    }

    @ManyToOne(cascade = CascadeType.REFRESH)
    @JoinColumn(name = "BOARD_ID")
    private Board board;

    public void setBoard(Board board) {
        this.board = board;
        if (!board.getComments().contains(this)) {
            board.setComment(this);
        }
    }


    public enum CommentPrivacyStatus {
        COMMENT_PUBLIC("전체 공개", 1),
        COMMENT_SECRET("비공개", 2);
        @Getter
        private String status;

        @Getter
        private int stepNumber;

        CommentPrivacyStatus(String status, int stepNumber) {
            this.status = status;
            this.stepNumber = stepNumber;
        }
    }
}

