package spingboot.comment.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import spingboot.comment.dto.CommentPostDto;
import spingboot.comment.entity.Comment;

@Mapper(componentModel = "spring")
public interface CommentMapper {
    @Mapping(source = "boardId",target = "board.boardId")
    @Mapping(source = "memberId", target = "member.memberId")
    @Mapping(source = "comment",target = "comment" )
    Comment commentPostDtoToComment(CommentPostDto commentPostDto);

}
