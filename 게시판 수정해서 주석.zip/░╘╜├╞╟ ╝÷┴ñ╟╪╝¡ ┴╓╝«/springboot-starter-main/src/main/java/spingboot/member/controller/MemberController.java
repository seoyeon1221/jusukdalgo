package spingboot.member.controller;


import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import spingboot.member.dto.MemberPostDto;
import spingboot.member.entity.Member;
import spingboot.member.mapper.MemberMapper;
import spingboot.member.service.MemberService;
import spingboot.response.SingleResponseDto;
import spingboot.utils.UriCreator;

import javax.validation.Valid;
import javax.validation.constraints.Positive;
import java.net.URI;

@RestController
@RequestMapping("/ver1/members")
@Validated
@Slf4j
public class MemberController {
    private static final String MEMBER_DEFAULT_URL = "/ver/1/members";

    private final MemberService memberService;
    private final MemberMapper mapper;

    public MemberController(MemberService memberService, MemberMapper mapper) {
        this.memberService = memberService;
        this.mapper = mapper;
    }

    @PostMapping
    public ResponseEntity postMember(@Valid @RequestBody MemberPostDto memberPostDto) {
        Member postMember = memberService.createMember(mapper.memberPostDtoToMember(memberPostDto));
        URI location = UriCreator.createUri(MEMBER_DEFAULT_URL, postMember.getMemberId());
        return ResponseEntity.created(location).build();
    }

    @GetMapping("{member-id}")
    public ResponseEntity getMember( @PathVariable("member-id") @Positive long memberId) {
        Member getMember = memberService.findMember(memberId);
        return new ResponseEntity<>(
                new SingleResponseDto<>(mapper.memberToMemberResponseDto(getMember)), HttpStatus.OK);
    }
    @DeleteMapping("{member-id}")
    public void deleteMember(@PathVariable("member-id")@Positive long memberId){
        memberService.deleteMember(memberId);
    }
}
