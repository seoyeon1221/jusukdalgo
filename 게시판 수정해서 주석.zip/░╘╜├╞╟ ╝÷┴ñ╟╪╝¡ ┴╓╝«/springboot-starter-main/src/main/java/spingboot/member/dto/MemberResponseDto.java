package spingboot.member.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import spingboot.member.entity.Member;

import java.time.LocalDateTime;

@Getter
@AllArgsConstructor
public class MemberResponseDto {
    private long memberId;
    private String name;
    private String email;
    private String phone;
    private Member.MemberStatus memberStatus;
    LocalDateTime createdAt;
}

