package spingboot.member.mapper;

import org.mapstruct.Mapper;
import spingboot.member.dto.MemberPostDto;
import spingboot.member.dto.MemberResponseDto;
import spingboot.member.entity.Member;

@Mapper(componentModel = "spring")
public interface MemberMapper {
    Member memberPostDtoToMember(MemberPostDto memberPostDto);
    MemberResponseDto memberToMemberResponseDto(Member member);
}
