package spingboot.member.service;

import org.springframework.stereotype.Service;
import spingboot.board.entity.Board;
import spingboot.exception.BusinessLogicException;
import spingboot.exception.ExceptionCode;
import spingboot.member.entity.Member;
import spingboot.member.repository.MemberRepository;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class MemberService {
    private final MemberRepository memberRepository;

    public MemberService(MemberRepository memberRepository) {
        this.memberRepository = memberRepository;
    }


    public Member createMember(Member member) {
        verifyExistEmail(member.getEmail());
        return memberRepository.save(member);
    }

    public Member updatedMember(Member member) {
        Member findMember = verifyMemberStatus(member);
        Optional.ofNullable(member.getName())
                .ifPresent(name -> findMember.setName(name
                ));
        Optional.ofNullable(member.getEmail())
                .ifPresent(email -> findMember.setEmail(email));
        Optional.ofNullable(member.getPhone())
                .ifPresent(phone -> findMember.setPhone(phone
                ));
        Optional.ofNullable(member.getMemberStatus())
                .ifPresent(memberStatus -> findMember.setMemberStatus(memberStatus
                ));

        findMember.setModifiedAt(LocalDateTime.now());
        return memberRepository.save(findMember);


    }

    public Member findMember(long memberId) {
        Member findMember = findVerifiedMember(memberId);
        return verifyMemberStatus(findMember);
    }

    public void deleteMember(long memberId) {
        Member findMember = verifyMemberStatus(findVerifiedMember(memberId));
        findMember.setMemberStatus(Member.MemberStatus.MEMBER_QUIT);
        findMember.getBoards().forEach(board -> board.setBoardStatus(Board.BoardStatus.QUESTION_DEACTIVED));
        findMember.getBoards().forEach(board -> board.setPrivacyStatus(Board.PrivacyStatus.BOARD_SECRET));
        memberRepository.save(findMember);

    }

    public void verifyExistEmail(String email) {
        Optional<Member> findByEmail = memberRepository.findByEmail(email);
        if (findByEmail.isPresent()) {
            throw new BusinessLogicException(ExceptionCode.MEMBER_EXISTS);
        }
    }

    public Member findVerifiedMember(long memberId) {
        Optional<Member> findByIdMember = memberRepository.findById(memberId);
        return findByIdMember.orElseThrow(() -> new BusinessLogicException(ExceptionCode.MEMBER_NOT_FOUND));
    }

    public Member verifyMemberStatus(Member member) {
        Member findMember = findVerifiedMember(member.getMemberId());
        // findMember 객체의 getMemberStatus() 메서드를 호출하여 회원의 현재 상태를 가져옴
        // 가져온 상태가 Member.MemberStatus.MEMBER_ACTIVE와 같은지 equals() 메서드로 비교하는데
        // equals() 메서드의 결과를 ! 연산자를 통해 반전시켜 최종적으로 회원 상태가 ACTIVE가 아닌 경우에만 true를 반환한다
        // 그렇다면 왜 ! 연산자를 통해 반전시킬까?
        // 왜냐면 회원의 상태가 ACTIVE 아닐 때만 블록 코드를 실행해야하기 때문
        // 즉, 멤버를 찾을 수 없다는 경고메세지를 출력하는거
        if (!findMember.getMemberStatus().equals(Member.MemberStatus.MEMBER_ACTIVE)) {
            throw new BusinessLogicException(ExceptionCode.MEMBER_NOT_FOUND);
        } //만일 찾을 수 있을 때면 멤버를 찾아서 반환함
        return findMember;
    }

}
