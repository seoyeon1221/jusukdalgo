package spingboot.response;

import lombok.Getter;

@Getter
public enum PageDirection {
    PAGE_CREATEDATDESC,
    PAGE_CREATEDATASC,
    PAGE_LIKESDESC,
    PAGE_LIKESASC,
    PAGE_VIEWSDESC,
    PAGE_VIEWSASC;

}
